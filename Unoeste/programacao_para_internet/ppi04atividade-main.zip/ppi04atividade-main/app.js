import express from 'express';
import session from 'express-session';
import cookieParser from 'cookie-parser';

const app = express()
  .use(cookieParser())
  .use(session({
    secret: 'jorelBrother',
    resave: false,
    saveUninitialized: true
  }))
  .use(express.urlencoded({ extended: true }))
  .use(express.json());

const port = 3000;

const style = `
<style>
  body {
    font-family: Arial, Helvetica, sans-serif;
    background: #f2f2f2;
    margin: 0;
    padding: 0;
  }

  h1, h2 {
    text-align: center;
    color: #333;
  }

  form {
    background: white;
    width: 400px;
    margin: 20px auto;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
  }

  label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
    color: #444;
  }

  input {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #aaa;
    border-radius: 5px;
    font-size: 14px;
  }

  button {
    width: 100%;
    padding: 12px;
    background: #0078ff;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    color: white;
    cursor: pointer;
    transition: 0.3s;
  }

  button:hover {
    background: #005fcc;
  }

  table {
    width: 90%;
    margin: 20px auto;
    border-collapse: collapse;
    background: white;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
  }

  table th {
    padding: 10px;
    background: #0078ff;
    color: white;
    text-align: left;
  }

  table td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
  }

  a {
    display: inline-block;
    margin-left: 20px;
    color: #0078ff;
    text-decoration: none;
    font-weight: bold;
  }

  a:hover {
    text-decoration: underline;
  }

  p {
    text-align: center;
  }
</style>
`;

const predefinedUsers = [
  { username: "joão", password: "1234" },
  { username: "maria", password: "abcd" },
  { username: "admin", password: "admin123" }
];

let productList = [];


app.get('/login', (req, res) => {
  res.send(`
    <html>
    <head><title>Login</title></head>
    ${style}
    <body>
      <h1>Login</h1>
      <form action="/login" method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <button type="submit">Log In</button>
      </form>
    </body>
    </html>
  `);
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  const user = predefinedUsers.find(
    u => u.username === username && u.password === password
  );

  if (!user) {
    return res.send(`
      <p>Invalid username or password!</p>
      <a href="/login">Try again</a>
    `);
  }

  req.session.username = username;
  res.cookie('lastAccess', new Date().toISOString());
  res.redirect('/products');
});

app.get('/products', (req, res) => {
  if (!req.session.username) {
    return res.send('You must log in first. <a href="/login">Go to Login</a>');
  }

  const lastAccess = req.cookies.lastAccess || 'Never';

  let table = `
    <table border="1">
      <tr>
        <th>Barcode</th>
        <th>Description</th>
        <th>Cost Price</th>
        <th>Selling Price</th>
        <th>Expiration Date</th>
        <th>Stock Quantity</th>
        <th>Manufacturer</th>
      </tr>
  `;

  productList.forEach(product => {
    table += `
      <tr>
        <td>${product.barcode}</td>
        <td>${product.description}</td>
        <td>${product.costPrice}</td>
        <td>${product.sellingPrice}</td>
        <td>${product.expirationDate}</td>
        <td>${product.stockQuantity}</td>
        <td>${product.manufacturer}</td>
      </tr>
    `;
  });

  table += `</table>`;

  res.send(`
    <html>
    <head><title>Product Registration</title></head>
    ${style}
    <body>
      <h1>Product Registration</h1>

      <p>Logged in as: ${req.session.username}</p>
      <p>Last access: ${lastAccess}</p>

      <form action="/products" method="POST">
        <label for="barcode">Barcode:</label>
        <input type="text" id="barcode" name="barcode" required><br><br>

        <label for="description">Description:</label>
        <input type="text" id="description" name="description" required><br><br>

        <label for="costPrice">Cost Price:</label>
        <input type="number" step="0.01" id="costPrice" name="costPrice" required><br><br>

        <label for="sellingPrice">Selling Price:</label>
        <input type="number" step="0.01" id="sellingPrice" name="sellingPrice" required><br><br>

        <label for="expirationDate">Expiration Date:</label>
        <input type="date" id="expirationDate" name="expirationDate" required><br><br>

        <label for="stockQuantity">Stock Quantity:</label>
        <input type="number" id="stockQuantity" name="stockQuantity" required><br><br>

        <label for="manufacturer">Manufacturer:</label>
        <input type="text" id="manufacturer" name="manufacturer" required><br><br>

        <button type="submit">Add Product</button>
      </form>

      <h2>Registered Products</h2>
      ${table}

      <br><a href="/logout">Log Out</a>
    </body>
    </html>
  `);
});

app.post('/products', (req, res) => {
  if (!req.session.username) {
    return res.send('You must log in first. <a href="/login">Go to Login</a>');
  }

  const { barcode, description, costPrice, sellingPrice, expirationDate, stockQuantity, manufacturer } = req.body;

  productList.push({
    barcode,
    description,
    costPrice,
    sellingPrice,
    expirationDate,
    stockQuantity,
    manufacturer
  });

  res.cookie('lastAccess', new Date().toISOString());
  res.redirect('/products');
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.clearCookie('lastAccess');
  res.redirect('/login');
});

app.listen(port, () => {
  console.log(port);
});
