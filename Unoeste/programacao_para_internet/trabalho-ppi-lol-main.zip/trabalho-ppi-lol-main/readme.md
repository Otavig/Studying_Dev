O usuario é admin
A senha é admin

Professor esse código não foi utilizado LMM por parte de back, por parte de front eu o utilizei para estilização, mas se tiver dúvidas sobre minha competência pode dar uma olhada aqui no git meus outros projetos e trabahos!!! 

