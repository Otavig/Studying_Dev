import express from "express";
import session from "express-session";
import cookieParser from "cookie-parser";

const app = express();
const porta = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
    secret: 'minhasenhasuperlegal123estoumorrendodefelicidadesescrevendo',
    resave: false,
    saveUninitialized: true
}));

function verificarLogin(req, res, next) {
    if (!req.session.user) {
        return res.send("Usuário não logado!");
    }
    next();
}

let equipes = [];
let styles = `
    @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&display=swap');

    :root {
        --cor-fundo-escuro: #050A15;
        --cor-fundo-claro: #0A0F1F;
        --cor-ouro: #FFD700;
        --cor-clara-texto: #D7C99A;
        --cor-clara-input: #FFF3C3;
        --fonte-principal: 'Cinzel', 'Friz Quadrata', serif;
        --sombra-interna-card: inset 0 0 20px rgba(26, 42, 71, 0.9);
        --sombra-externa-card: 0 0 16px rgba(255, 215, 0, 0.7);
        --text-shadow-ouro: 0 0 6px var(--cor-ouro), 0 0 12px rgba(255, 215, 0, 0.7);
    }

    body {
        margin: 0;
        padding: 0;
        background: linear-gradient(135deg, var(--cor-fundo-escuro), var(--cor-fundo-claro) 90%);
        font-family: var(--fonte-principal), 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: var(--cor-clara-texto);
        min-height: 100vh;
        background-color: #030507;
        background-image:
          radial-gradient(circle at 10% 10%, rgba(255, 214, 104, 0.05), transparent 85%),
          radial-gradient(circle at 90% 90%, rgba(255, 214, 104, 0.05), transparent 75%);
    }

    .container {
        padding: 40px 20px;
        margin: 0 auto;
        color: var(--cor-clara-texto);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .center-screen {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        padding: 20px;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 40px 20px;
    }

    .card {
        display: flex;
        flex-direction: column;
        background: var(--glass-bg);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid var(--glass-border);
        border-top: 2px solid var(--hex-gold);
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.5);
        padding: 40px;
        width: 100%;
        position: relative;
        animation: slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .card::before, .card::after {
        content: '';
        position: absolute;
        width: 10px;
        height: 10px;
        border: 2px solid var(--hex-cyan);
        transition: all 0.3s ease;
    }
    .card::before { top: -2px; left: -2px; border-right: none; border-bottom: none; }
    .card::after { bottom: -2px; right: -2px; border-left: none; border-top: none; }

    h1, h2 {
        font-family: 'Cinzel', serif;
        color: var(--hex-gold);
        text-transform: uppercase;
        letter-spacing: 2px;
        text-align: center;
        margin-bottom: 30px;
        text-shadow: 0 0 10px rgba(200, 170, 110, 0.4);
        position: relative;
    }

    h1::after {
        content: '';
        display: block;
        width: 60px;
        height: 3px;
        background: linear-gradient(90deg, transparent, var(--hex-cyan), transparent);
        margin: 10px auto 0;
    }

    form label {
        display: block;
        margin-top: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        color: var(--hex-cyan);
        letter-spacing: 1px;
    }

    form input, form select {
        width: 100%;
        background: rgba(0, 0, 0, 0.3);
        border: none;
        border-bottom: 2px solid #333;
        color: #fff;
        padding: 12px 10px;
        font-size: 1rem;
        font-family: 'Montserrat', sans-serif;
        transition: all 0.3s ease;
        margin-top: 5px;
    }

    form input:focus, form select:focus {
        outline: none;
        background: rgba(10, 200, 185, 0.05);
        border-bottom-color: var(--hex-gold);
        box-shadow: 0 4px 6px -4px var(--hex-gold);
    }

    .btn, form button, .button-style {
        width: 100%;
        margin-top: 30px;
        padding: 15px;
        background: linear-gradient(45deg, #9e8248, #c8aa6e);
        border: none;
        color: #010a13;
        font-family: 'Cinzel', serif;
        font-weight: 700;
        font-size: 1.1rem;
        text-transform: uppercase;
        letter-spacing: 1px;
        cursor: pointer;
        position: relative;
        clip-path: polygon(10px 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%, 0 10px);
        transition: all 0.3s ease;
    }

    .btn:hover, form button:hover, .button-style:hover {
        transform: translateY(-2px);
        filter: brightness(1.2);
        box-shadow: 0 0 15px rgba(200, 170, 110, 0.6);
    }

    a.btn-link, .container > a {
        display: block;
        text-align: center;
        margin-top: 15px;
        color: var(--hex-cyan);
        text-decoration: none;
        font-size: 0.9rem;
        transition: color 0.3s;
        border: 1px solid rgba(10, 200, 185, 0.3);
        padding: 10px;
        background: rgba(10, 200, 185, 0.05);
    }

    a.btn-link:hover, .container > a:hover {
        background: rgba(10, 200, 185, 0.15);
        color: #fff;
        border-color: var(--hex-cyan);
        box-shadow: 0 0 10px rgba(10, 200, 185, 0.2);
    }

    .container a[style*="color:red"] {
        border-color: #ff4d4d;
        color: #ff4d4d !important;
    }
    .container a[style*="color:red"]:hover {
        background: rgba(255, 77, 77, 0.1);
        box-shadow: 0 0 10px rgba(255, 77, 77, 0.4);
    }

    table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 8px;
        margin-top: 20px;
    }

    th {
        text-align: left;
        color: var(--hex-gold);
        font-family: 'Cinzel', serif;
        padding: 15px;
        border-bottom: 2px solid var(--hex-cyan);
        font-size: 0.9rem;
    }

    tbody tr {
        background: rgba(15, 25, 45, 0.6);
        transition: transform 0.2s, background 0.2s;
    }

    tbody tr:hover {
        transform: scale(1.01);
        background: rgba(15, 25, 45, 0.9);
        box-shadow: 0 0 10px rgba(0,0,0,0.5);
    }

    td {
        padding: 15px;
        border: none;
        border-right: 1px solid rgba(255,255,255,0.05);
    }
    
    td:first-child { border-left: 2px solid transparent; }
    tbody tr:hover td:first-child { border-left-color: var(--hex-gold); }

    table button {
        padding: 6px 12px;
        font-size: 0.8rem;
        margin-right: 5px;
        width: auto !important;
        background: transparent !important;
        border: 1px solid var(--hex-gold) !important;
        color: var(--hex-gold) !important;
        clip-path: none !important;
    }
    table button:hover {
        background: var(--hex-gold) !important;
        color: #000 !important;
    }

    @keyframes slideUp {
        from { opacity: 0; transform: translateY(40px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 768px) {
        table, thead, tbody, th, td, tr { display: block; }
        thead tr { position: absolute; top: -9999px; left: -9999px; }
        tr { margin-bottom: 15px; border: 1px solid var(--hex-blue-deep); }
        td { border: none; position: relative; padding-left: 50%; text-align: right; }
        td:before { position: absolute; top: 15px; left: 15px; width: 45%; white-space: nowrap; content: attr(data-label); text-align: left; color: var(--hex-cyan); font-weight: bold; }
        .card { padding: 25px; }
    }
`;

app.post("/criar-equipe", verificarLogin, (req, res) => {
    const { nome, capitao, contato } = req.body;
    const idEquipe = Date.now().toString();

    if (!nome) return res.send("O nome da equipe é obrigatório!");
    if (equipes.some(equipe => equipe.nome === nome)) return res.send("Já existe outra equipe com esse nome!");
    if (!capitao) return res.send("O nome do capitão é obrigatório!");
    if (!contato) return res.send("O número do capitão é obrigatório!");

    const contatoSomenteNumeros = contato.replace(/\D/g, "");
    if (contatoSomenteNumeros.length < 10) return res.send("O número do capitão é inválido!");

    equipes.push({
        id: idEquipe,
        nome: nome,
        capitao,
        contatoCapitao: contatoSomenteNumeros,
        jogadores: []
    });

    return res.send("Equipe criada com sucesso!");
});

app.post("/atualizar-equipe/:id", verificarLogin, (req, res) => {
    const idEquipe = req.params.id;
    const equipeEncontrada = equipes.find(equipe => equipe.id === idEquipe);

    if (!equipeEncontrada) return res.send("Equipe não encontrada!");

    const { nome, capitao, contato } = req.body;

    if (
        nome === equipeEncontrada.nome &&
        capitao === equipeEncontrada.capitao &&
        contato === equipeEncontrada.contatoCapitao
    ) {
        return res.send("Nenhuma informação foi alterada!");
    }

    if (nome) {
        if (equipes.some(equipe => equipe.nome === nome && equipe.id !== idEquipe)) {
            return res.send("Já existe outra equipe com esse nome!");
        }
        equipeEncontrada.nome = nome;
    }
    if (capitao) equipeEncontrada.capitao = capitao;
    if (contato) equipeEncontrada.contatoCapitao = contato.replace(/\D/g, "");

    return res.send("Equipe atualizada com sucesso!");
});

app.post("/remover-equipe/:id", verificarLogin, (req, res) => {
    const idEquipe = req.params.id;
    const indiceEquipe = equipes.findIndex(equipe => equipe.id === idEquipe);

    if (indiceEquipe === -1) return res.send("Equipe não encontrada!");

    equipes.splice(indiceEquipe, 1);
    return res.send("Equipe excluída com sucesso!");
});

app.get("/listar-equipes", verificarLogin, (req, res) => {
    return res.send(equipes);
});

app.post("/adicionar-jogador/:idEquipe", verificarLogin, (req, res) => {
    const { nome, nick, funcao, elo, genero } = req.body;
    const { idEquipe } = req.params;

    const indiceEquipe = equipes.findIndex(equipe => equipe.id === idEquipe);
    if (indiceEquipe === -1) return res.send("Equipe não encontrada!");

    if (equipes[indiceEquipe].jogadores.length >= 5) return res.send("Equipe já está cheia!");

    const idJogador = Date.now().toString();
    equipes[indiceEquipe].jogadores.push({ id: idJogador, nome, nick, funcao, elo, genero });

    return res.send("Jogador adicionado com sucesso à equipe!");
});

app.post("/editar-jogador/:idJogador", verificarLogin, (req, res) => {
    const idJogador = req.params.idJogador;
    const { nome, nick, funcao, elo, genero, idEquipe } = req.body;

    let equipeDoJogador = null;
    let jogadorParaEditar = null;
    for (const equipe of equipes) {
        const jogadorEncontrado = equipe.jogadores.find(jogador => jogador.id === idJogador);
        if (jogadorEncontrado) {
            equipeDoJogador = equipe;
            jogadorParaEditar = jogadorEncontrado;
            break;
        }
    }

    if (!jogadorParaEditar) return res.send("Jogador não encontrado!");

    if (nome) jogadorParaEditar.nome = nome;
    if (nick) jogadorParaEditar.nick = nick;
    if (funcao) jogadorParaEditar.funcao = funcao;
    if (elo) jogadorParaEditar.elo = elo;
    if (genero) jogadorParaEditar.genero = genero;

    return res.send(`Jogador atualizado com sucesso!`);
});

app.post("/remover-jogador/:idJogador", verificarLogin, (req, res) => {
    const idJogador = req.params.idJogador;

    for (const equipe of equipes) {
        const indiceJogador = equipe.jogadores.findIndex(jogador => jogador.id === idJogador);
        if (indiceJogador !== -1) {
            equipe.jogadores.splice(indiceJogador, 1);
            return res.send(`Jogador excluído com sucesso da equipe ${equipe.nome}!`);
        }
    }

    return res.send("Jogador não encontrado!");
});

app.post('/entrar', (req, res) => {
    const { usuario, senha } = req.body;

    if (usuario === 'admin' && senha === 'admin') {
        req.session.user = usuario;
        const agora = new Date().toISOString();
        res.cookie('ultimoAcesso', agora, { maxAge: 24 * 60 * 60 * 1000, httpOnly: false });
        return res.send(telaDeMenu(req));
    }

    return res.send(telaDeLogin());
});

app.get('/sair', (req, res) => {
    req.session.destroy(erro => {
        if (erro) return res.send('Erro ao sair da sessão.');

        res.clearCookie('connect.sid');
        res.clearCookie('ultimoAcesso');
        res.redirect('/');
    });
});

function telaDeLogin() {
    return `
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <title>Acesso</title>
            <style>${styles}</style>
        </head>
        <body>
        <div class="card center-screen">
            <h1>Acessar Conta</h1>

            <form id="loginFormNova" method="POST" action="/entrar">
                <label>Nome de Usuário:</label>
                <input type="text" name="usuario" placeholder="Digite seu usuário" required>

                <label>Senha:</label>
                <input type="password" name="senha" placeholder="Digite sua senha" required>

                <button type="submit" class="btn">Entrar</button>
            </form>
        </div>

        <script>
            const loginFormNova = document.getElementById('loginFormNova');
            loginFormNova.addEventListener('submit', function(e){
                e.preventDefault();
                this.submit(); 
            });
        </script>

        </body>
        </html>
    `;
}

function telaDeCadastroEquipe() {
    return `
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <title>Nova Equipe</title>
            <style>${styles}</style>
        </head>
        <body>
        <div class="card center-screen">
            <h1>Registrar Equipe</h1>

            <form id="formNovaEquipe" method="POST" action="/criar-equipe">
                <label>Nome da Equipe:</label>
                <input type="text" name="nome" placeholder="Digite o nome da equipe" required>

                <label>Capitão:</label>
                <input type="text" name="capitao" placeholder="Nome do capitão" required>

                <label>Contato:</label>
                <input type="text" name="contato" placeholder="Telefone ou WhatsApp" required>

                <button type="submit" class="btn">Cadastrar Equipe</button>
            </form>

            <a href="/page/inicio" class="btn-link">Voltar ao Menu</a>
        </div>
        </body>
        </html>
    `;
}

function telaDeMenu(req) {
    const ultimoAcesso = req.cookies.ultimoAcesso 
        ? new Date(req.cookies.ultimoAcesso).toLocaleString('pt-BR')
        : "Não registrado";

    return `
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
                <meta charset="UTF-8">
                <title>Menu</title>
                <style>${styles}</style>
            </head>

            <body>
                <div class="container">
                    <h1>Menu Principal</h1>

                    <p><strong>Último acesso:</strong> ${ultimoAcesso}</p>
                    <br>

                    <a href="/page/cadastro-equipes">Cadastro de Equipes</a>
                    <a href="/page/cadastro-jogador">Cadastro de Jogadores</a>
                    <a href="/page/listar-equipes">Listar Equipes</a>
                    <a href="/page/listar-jogadores">Listar Jogadores</a>
                    <br>

                    <a style="color:red" href="/sair">Logout</a>
                </div>
            </body>
            </html>
        `
}

function telaDeCadastroJogador() {
    let options = equipes.map(eq => `<option value="${eq.id}">${eq.nome}</option>`).join("");

    return `
    <!DOCTYPE html>
    <html lang="pt-BR">

    <head>
        <meta charset="UTF-8">
        <title>Cadastro Jogador</title>
        <style>${styles}</style>
    </head>

    <body>
    <div class="card center-screen">
        <h1>Cadastrar Jogador</h1>

        <form id="formJogador" method="POST">
            <label>Nome:</label>
            <input type="text" name="nome" required>

            <label>Nickname:</label>
            <input type="text" name="nick" required>

            <label>Função:</label>
            <select name="funcao" required>
                <option value="">Selecione...</option>
                <option value="top">Top</option>
                <option value="jungle">Jungle</option>
                <option value="mid">Mid</option>
                <option value="atirador">Atirador</option>
                <option value="suporte">Suporte</option>
            </select>

            <label>Elo:</label>
            <input type="text" name="elo" required>

            <label>Gênero:</label>
            <select name="genero" required>
                <option value="">Selecione...</option>
                <option>M</option>
                <option>F</option>
                <option>Outro</option>
            </select>

            <label>Equipe:</label>
            <select name="idEquipe" id="idEquipe" required>
                ${options}
            </select>

            <button type="submit" class="btn">Cadastrar</button>
        </form>

        <a href="/page/inicio" class="btn-link">Voltar ao Menu</a>
    </div>

    <script>
        const form = document.getElementById('formJogador');
        form.addEventListener('submit', function(e){
            e.preventDefault();
            const idEquipe = document.getElementById('idEquipe').value;
            this.action = '/adicionar-jogador/' + idEquipe;
            this.submit();
        });
    </script>
    </body>
    </html>
    `;
}

function telaDeListaEquipes() {
    let linhas = equipes.map(e => {
        let jogadoresList = e.jogadores.length > 0
            ? e.jogadores.map(j => `${j.nome} (${j.nick}) - ${j.funcao}`).join("<br>")
            : "<em>Sem jogadores cadastrados</em>";

        return `
        <tr>
            <td data-label="Nome da Equipe">${e.nome}</td>
            <td data-label="Capitão">${e.capitao}</td>
            <td data-label="Jogadores">${jogadoresList}</td>
            <td data-label="Ações">
                <button type="button" onclick="
                    document.getElementById('editar-${e.id}').style.display='table-row'; 
                    this.style.display='none';
                ">Editar</button>
                <form method="POST" action="/remover-equipe/${e.id}" onsubmit="return confirm('Deseja realmente excluir esta equipe?');" style="margin-top:10px;">
                    <button type="submit">Excluir</button>
                </form>
            </td>
        </tr>
        <tr id="editar-${e.id}" style="display:none;">
            <td colspan="4">
                <form method="POST" action="/atualizar-equipe/${e.id}">
                    <label>Nome da Equipe:</label>
                    <input type="text" name="nome" value="${e.nome}" required>

                    <label>Capitão:</label>
                    <input type="text" name="capitao" value="${e.capitao}" required>

                    <label>Contato do Capitão:</label>
                    <input type="text" name="contato" value="${e.contatoCapitao || ''}" required>

                    <button type="submit" class="button-style" style="margin-top:15px; width: auto;">Salvar Alterações</button>
                </form>
            </td>
        </tr>`;
    }).join("");

    return `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Equipes</title>
        <style>
            ${styles}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Equipes Cadastradas</h1>
            <table>
                <thead>
                    <tr>
                        <th>Nome da Equipe</th>
                        <th>Capitão</th>
                        <th>Jogadores</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${linhas}
                </tbody>
            </table>
            <a href="/page/inicio" class="btn-link">Voltar ao Menu</a>
        </div>
    </body>
    </html>
    `;
}

function telaDeListaJogadores() {
    let linhas = equipes.map(eq =>
        eq.jogadores.map(j => {
            let options = equipes.map(e => 
                `<option value="${e.id}" ${e.id === eq.id ? "selected" : ""}>${e.nome}</option>`
            ).join("");

            return `
            <tr>
                <td data-label="Nome">${j.nome}</td>
                <td data-label="Nickname">${j.nick}</td>
                <td data-label="Função">${j.funcao}</td>
                <td data-label="Elo">${j.elo}</td>
                <td data-label="Gênero">${j.genero}</td>
                <td data-label="Equipe">${eq.nome}</td>
                <td data-label="Ações">
                    <button type="button" onclick="
                        const row = document.getElementById('editar-${j.id}');
                        if (row) {
                            row.style.display='table-row';
                            this.style.display='none';
                        }
                    ">Editar</button>
                    <form method="POST" action="/remover-jogador/${j.id}" onsubmit="return confirm('Deseja realmente excluir este jogador?');" style="margin-top:10px;">
                        <button type="submit">Excluir</button>
                    </form>
                </td>
            </tr>
            <tr id="editar-${j.id}" style="display:none;">
                <td colspan="7">
                    <form method="POST" action="/editar-jogador/${j.id}">
                        <label>Nome:</label>
                        <input type="text" name="nome" value="${j.nome}" required>

                        <label>Nickname:</label>
                        <input type="text" name="nick" value="${j.nick}" required>

                        <label>Função:</label>
                        <select name="funcao" required>
                            <option value="top" ${j.funcao === 'top' ? 'selected' : ''}>Top</option>
                            <option value="jungle" ${j.funcao === 'jungle' ? 'selected' : ''}>Jungle</option>
                            <option value="mid" ${j.funcao === 'mid' ? 'selected' : ''}>Mid</option>
                            <option value="atirador" ${j.funcao === 'atirador' ? 'selected' : ''}>Atirador</option>
                            <option value="suporte" ${j.funcao === 'suporte' ? 'selected' : ''}>Suporte</option>
                        </select>

                        <label>Elo:</label>
                        <input type="text" name="elo" value="${j.elo}" required>

                        <label>Gênero:</label>
                        <select name="genero" required>
                            <option value="M" ${j.genero === 'M' ? 'selected' : ''}>M</option>
                            <option value="F" ${j.genero === 'F' ? 'selected' : ''}>F</option>
                            <option value="Outro" ${j.genero === 'Outro' ? 'selected' : ''}>Outro</option>
                        </select>

                        <label>Equipe:</label>
                        <select name="idEquipe" required>
                            ${options}
                        </select>

                        <button type="submit" class="button-style" style="margin-top:15px; width: auto;">Salvar Alterações</button>
                    </form>
                </td>
            </tr>
            `;
        }).join("")
    ).join("");

    return `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Jogadores</title>
        <style>
            ${styles}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Jogadores Cadastrados</h1>
            <table>
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Nickname</th>
                        <th>Função</th>
                        <th>Elo</th>
                        <th>Gênero</th>
                        <th>Equipe</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${linhas}
                </tbody>
            </table>
            <a href="/page/inicio" class="btn-link">Voltar ao Menu</a>
        </div>
    </body>
    </html>
    `;
}


app.get("/page/:page", (req, res) => {
    const page = req.params.page;
    
    if (page === "login") {
        return res.send(telaDeLogin());
    }

    if (!req.session.user) {
        return res.redirect("/page/login");
    }

    if(page === "inicio") {
        return res.send(telaDeMenu(req));
    }

    if(page === "cadastro-equipes") {
        return res.send(telaDeCadastroEquipe());
    }

    if(page === "cadastro-jogador") {
        return res.send(telaDeCadastroJogador());
    }

    if(page === "listar-equipes") { 
        return res.send(telaDeListaEquipes());
    }

    if(page === "listar-jogadores") {  
        return res.send(telaDeListaJogadores());
    }

    res.redirect("/page/login");
});


app.use((req, res, next) => {
    if (req.path == "/") {
        return res.redirect("/page/login");
    }
    next();
});

app.listen(porta, () => console.log(`Rodando ${porta}`));
