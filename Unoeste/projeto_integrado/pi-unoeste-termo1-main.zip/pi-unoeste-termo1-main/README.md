<img src="https://github.com/Otavig/pi-unoeste-termo1/blob/main/2.png"/>

# Equipe de Desenvolvimento

## Analistas de Requisitos
- **Breno Passarela** (Atua como analista, mas pode auxiliar em ambas as partes para aprendizado)
- **Matheus Bispo** (Foco)

## Projetistas de Software
- **Kaua** (Foco, mas assim que terminado, pode auxiliar em ambas as partes)

## Projetistas de Interface
- **Lucas Ronaldo** (Foco, mas podendo, depois das decisões, ajudar no desenvolvimento)
- *Auxílio dos front-ends*

## Desenvolvedores de Web-Site

### Front-End
- **Breno Henrique** (Além de Scrum Master, atua no desenvolvimento da interface)
- **Guilherme**

### Back-End
- **Rafael Cestari** (Software, algumas ajudas no front caso necessário)
- **Otávio Garcia** (Atua em ambas as partes do projeto)
